#pragma once
#ifndef MUR
#define MUR

// include 
#include "../header/position.h"

// profil 
//bool estUnMur(Level* l, Position* p); 

#endif