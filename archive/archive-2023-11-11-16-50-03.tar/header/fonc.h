#pragma once
#ifndef FONC
#define FONC 

#endif