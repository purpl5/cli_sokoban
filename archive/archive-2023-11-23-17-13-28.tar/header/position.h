#pragma once
#ifndef POSITION
#define POSITION

// typedef 
typedef struct Position {
    int x;
    int y; 
} Position;

#endif 