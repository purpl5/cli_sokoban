#pragma once
#ifndef BLOC
#define BLOC

#endif