#pragma once
#ifndef BLOC
#define BLOC

// include 

// typedef

#endif