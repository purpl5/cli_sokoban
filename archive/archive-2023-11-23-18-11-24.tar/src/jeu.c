#include "../header/base.h"
#include "../header/jeu.h"

/*
void game() {

}
*/