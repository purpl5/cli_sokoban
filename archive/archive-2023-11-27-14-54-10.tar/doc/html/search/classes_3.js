var searchData=
[
  ['player_86',['Player',['../structPlayer.html',1,'']]],
  ['position_87',['Position',['../structPosition.html',1,'']]]
];
