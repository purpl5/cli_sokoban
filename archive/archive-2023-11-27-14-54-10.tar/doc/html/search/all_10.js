var searchData=
[
  ['stocklevelfile_77',['stockLevelFile',['../levelSelector_8h.html#a136e6ea4920c442b8e5b2081eed275b4',1,'stockLevelFile(LevelFile *list, char *namefile):&#160;levelSelector.c'],['../levelSelector_8c.html#a136e6ea4920c442b8e5b2081eed275b4',1,'stockLevelFile(LevelFile *list, char *namefile):&#160;levelSelector.c']]]
];
