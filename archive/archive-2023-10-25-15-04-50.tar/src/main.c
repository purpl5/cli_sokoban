#include "../header/base.h"

int main() {
    printf("test du makefile");
    
    return EXIT_SUCCESS;  
}