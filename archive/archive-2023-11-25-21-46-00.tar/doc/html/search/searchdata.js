var indexSectionsWithContent =
{
  0: "abcdefgijklmnoprstxy",
  1: "fjlp",
  2: "bejlmop",
  3: "acdefgilmnprs",
  4: "cflnptxy",
  5: "fjlp",
  6: "k"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Structures de données",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables",
  5: "Définitions de type",
  6: "Macros"
};

