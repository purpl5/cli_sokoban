#include "base.h"
#include "jeu.h"

int main() {
    gameOn();

    return EXIT_SUCCESS;
}