var searchData=
[
  ['name_133',['name',['../structLevelFile.html#a6778e96cfdce9bbb37e8d27e69187176',1,'LevelFile']]],
  ['next_134',['next',['../structfileEmplacement.html#ad872341bc2d46ceb39adf2f5d55c6b07',1,'fileEmplacement::next()'],['../structLevelFile.html#a74c2e1e89dca8aea3b80df141d25c247',1,'LevelFile::next()']]]
];
