var searchData=
[
  ['player_75',['Player',['../structPlayer.html',1,'']]],
  ['position_76',['Position',['../structPosition.html',1,'']]]
];
