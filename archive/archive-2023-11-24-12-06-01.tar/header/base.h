#pragma once
#ifndef BASE
#define BASE

// Les includes
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
//#include <math.h>

#endif